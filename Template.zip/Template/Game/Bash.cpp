/*
 * 有一堆n个石子，两人轮流取，每次取1-m个
 */ 
bool solve(int n,int m){
    return n%(m+1);
}

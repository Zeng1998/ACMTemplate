#include <bits/stdc++.h>
using namespace std;
const int N=2050;
const int M=6050;
struct Edge{
    int u,v,w;
};
vector<Edge> e;
int dis[N];
bool bellman_ford(int s,int n)}{
    for(int i=1;i<=n;i++){
        dis[i]=INF;
    }
    dis[s]=0;
    for(int i=1;i<n;i++){
        bool flag=false;
    }
}
int main(void){
    return 0;
}